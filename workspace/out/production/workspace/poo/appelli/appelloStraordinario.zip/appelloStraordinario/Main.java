package poo.appelli.appelloStraordinario;

import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
    Elenco<Parola> elenco = new ElencoConcatenato<>();

    public void scarica(String nomeFile) throws IOException {
        PrintWriter pw = new PrintWriter(new FileWriter(nomeFile));
        for(Parola p: elenco) pw.println(p);
        pw.close();
    }

    public void ripristina(String nomeFile) throws IOException{
        BufferedReader br = new BufferedReader(new FileReader(nomeFile));
        elenco.clear();
        String linea;
        for(;;){
            linea = br.readLine();
            if(linea == null) break; //EOF
            elenco.add(new Parola(linea));
        }
        br.close();
    }

    public static void main(String[] args){
        Main m = new Main();
        Scanner sc = new Scanner(System.in);
        StringTokenizer st = null;
        String linea = null;
        String COMANDO_W_PARAM = "[A-Z]\\s+\\w+";
        String COMANDO_WOUT_PARAM = "[A-Z]";
        comandi();
        System.out.println("Inserisci comando: ");
        ciclo: for(;;){
            linea = sc.nextLine();
            if(! (linea.matches(COMANDO_W_PARAM) || linea.matches(COMANDO_WOUT_PARAM))){
                System.out.println("Comando non valido"); continue;
            }
            st = new StringTokenizer(linea, " ");
            char comando = (st.nextToken().toUpperCase()).charAt(0);
            switch (comando){
                case 'A': {
                    if(!linea.matches(COMANDO_W_PARAM)){
                        System.out.println("Comando non valido"); continue;
                    }
                    m.aggiungi(new Parola(st.nextToken()));
                    break;
                }
                case 'D':{
                    if(!linea.matches(COMANDO_WOUT_PARAM)){
                        System.out.println("Comando non valido"); continue;
                    }
                    m.visualizza();
                    break;
                }
                case 'C':{
                    if(!linea.matches(COMANDO_WOUT_PARAM)){
                        System.out.println("Comando non valido"); continue;
                    }
                    m.compatta();
                    break;
                }
                case 'E':{
                    if(!linea.matches(COMANDO_W_PARAM)){
                        System.out.println("Comando non valido"); continue;
                    }
                    m.rimuovi(new Parola(st.nextToken()));
                    break;
                }
                case 'O':{
                    if(!linea.matches(COMANDO_WOUT_PARAM)){
                        System.out.println("Comando non valido"); continue;
                    }
                    m.ordina();
                    break;
                }
                case 'P':{
                    if(!linea.matches(COMANDO_W_PARAM)){
                        System.out.println("Comando non valido"); continue;
                    }
                    try{
                        m.scarica(st.nextToken());
                    }catch (IOException e){
                        System.out.println("nome File non valido");
                    }
                    break;
                }
                case 'R':{
                    if(!linea.matches(COMANDO_W_PARAM)){
                        System.out.println("Comando non valido"); continue;
                    }
                    try{
                        m.ripristina(st.nextToken());
                    }catch (IOException e){
                        System.out.println("nome File non valido");
                    }
                    break;
                }
                case 'T': { sc.close(); break ciclo;}
                default:
                    System.out.println("Comando non valido");
            }
        }
    }


    public static void comandi(){
        System.out.println("AGGIUNGI: A nome");
        System.out.println("VISUALIZZA: D");
        System.out.println("COMPATTA: C");
        System.out.println("RIMUOVI: E");
        System.out.println("ORDINA: O");
        System.out.println("SCARICA: P");
        System.out.println("RIPRISTINA: R");
        System.out.println("TERMINA: T");
    }

    public void aggiungi(Parola p){
        elenco.add(p);
    }

    public void visualizza(){
        if(elenco.size()==0) System.out.println("*elenco vuoto*");
        System.out.println(elenco);
    }

    public void compatta(){
        elenco.compatta();
    }

    public void ordina(){
        elenco.ordina();
    }

    public void rimuovi(Parola p){
        elenco.remove(p);
    }

}
