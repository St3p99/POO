package poo.polinomi;

public class Test {
    public static void main(String[] args) {
        //TODO: estrarre i monomi da una Stringa
        Polinomio p1 = new PolinomioMap();
        p1.add(new Monomio(-3,5));
        p1.add(new Monomio(5,3));
        p1.add(new Monomio(-2,1));
        p1.add(new Monomio(7,0));
        Polinomio p2 = new PolinomioLL();
        p2.add(new Monomio(-12,0));
        p2.add(new Monomio(2,4));
        p2.add(new Monomio(3,3));
        p2.add(new Monomio(-4,2));
        System.out.println("P1(x)="+p1);
        System.out.println("P2(x)="+p2);
        System.out.println("[P1+P2](x)="+p1.add(p2));
        System.out.println("[P1*P2](x)="+p1.mul(p2));
        System.out.println("[P1*P2]'(x)="+(p1.mul(p2)).derivata());
        p1.add(new Monomio(3,5));
        System.out.println("P1(x)="+p1);
    }
}
