package poo.polinomi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ApplicazioneGUI{
    private JFrame frame;
    private JPanel inputPanel, opPanel;
    private JButton[] operations;
    private JLabel[] operationResult;
    private JButton input_1, input_2;
    private Polinomio p1, p2;

    public ApplicazioneGUI(){
        frame = new JFrame("APP POLINOMIO");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(100, 300, 400, 400);
        setInputPanel();
        setOperationPanel();
        frame.setVisible(true);
    }
    
    private void setOperationPanel(){
        opPanel = new JPanel(new GridLayout(7,2,10,10));
        operations = new JButton[7];
        operationResult = new JLabel[7];
        ActionListener buttonListener = new OperationButton();
        for(int i=0; i<7; i++){
            JButton button = new JButton();
            JLabel label = new JLabel();
            button.addActionListener(buttonListener);
            opPanel.add(button); opPanel.add(label);
            operations[i] = button; operationResult[i] = label;
        }
        frame.getContentPane().add(opPanel);
        setStringOperationButton();
    }

    private void setStringOperationButton(){
        operations[0].setText("P1(x)");
        operations[1].setText("P2(x)");
        operations[2].setText("[P1*P2](x)");
        operations[3].setText("[P1 + P2](x)");
        operations[4].setText("[P1 - P2](x)");
        operations[5].setText("P1'(x)");
        operations[6].setText("P2'(x)");
    }

    private void operationButtonPressed(int n){
        if((n==0 || (n>=2 && n<=5)) && p1 == null){ JOptionPane.showMessageDialog(frame, "Dati mancanti!"); return;}
        if((n==6 || (n>=1 && n<=4)) && p2 == null){ JOptionPane.showMessageDialog(frame, "Dati mancanti!"); return;}
        switch(n){
            case 0:{ operationResult[0].setText("= "+p1); break;}
            case 1:{ operationResult[1].setText("= " + p2); break;}
            case 2:{ operationResult[2].setText("= " + p1.mul(p2)); break;}
            case 3:{ operationResult[3].setText("= " + p1.add(p2)); break;}
            case 4:{ operationResult[4].setText("= " + p1.add(p2.mul(new Monomio(-1,0)))); break;}
            case 5:{ operationResult[5].setText("= " + p1.derivata()); break;}
            case 6:{ operationResult[6].setText("= " + p2.derivata()); break;}
        }
    }

    class OperationButton implements ActionListener {
        public void actionPerformed(ActionEvent e){
            for(int i=0;i<operations.length;i++)
                if(e.getSource()==operations[i]){
                    operationButtonPressed(i); break;
                }
        }
    }
    
    private void setInputPanel(){
        inputPanel = new JPanel();
        input_1 = new JButton("Inserisci P1(x)");
        input_2 = new JButton("Inserisci P2(x)");
        ActionListener buttonListener = new InputButton();
        input_1.addActionListener(buttonListener);
        input_2.addActionListener(buttonListener);
        inputPanel.add(input_1);
        inputPanel.add(input_2);
        frame.getContentPane().add(BorderLayout.NORTH, inputPanel);
    }

    class InputButton implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == input_1) {
                setP1(); operationButtonPressed(0);
            }
            else if(e.getSource() == input_2){
                setP2(); operationButtonPressed(1);
            }
        }
    }

    private void setP1(){
        String inp;
        for(;;){
            inp = JOptionPane.showInputDialog(frame, "Inserisci P1(x): ");
            inp = removeSpaces(inp);
            if(inp.matches(PolinomioAstratto.POLINOMIO)) break;
            JOptionPane.showMessageDialog(frame, "Amico mio non matcha!");
        }
        this.p1 = new PolinomioMap(inp);
    }

    private void setP2(){
        String inp;
        for(;;){
            inp = JOptionPane.showInputDialog(frame, "Inserisci P2(x): ");
            inp = removeSpaces(inp);
            if(inp.matches(PolinomioAstratto.POLINOMIO)) break;
            JOptionPane.showMessageDialog(frame, "Amico mio non matcha!");
        }
        this.p2 = new PolinomioMap(inp);
    }


    public static void main(String[] args) {
        ApplicazioneGUI app = new ApplicazioneGUI();
    }

    public static String removeSpaces(String s){
        StringBuilder sb = new StringBuilder(s.length());
        int i = 0;
        while(i< s.length()){
            char c = s.charAt(i);
            if(c != ' ')
                sb.append(c);
            i++;
        }
        return sb.toString();
    }
}
