package poo.polinomi;

import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Iterator;
import java.util.Map;

public class PolinomioMap extends PolinomioAstratto {
    private Map<Monomio, Monomio> mappa = new TreeMap<>();

    public PolinomioMap(){}
    public PolinomioMap(Polinomio p){
        for(Monomio m: p) this.add(m);
    }
    public PolinomioMap(String linea){
        StringTokenizer st = new StringTokenizer(linea, "+-", true);
        while(st.hasMoreTokens()){
            String tk = st.nextToken();
            switch (tk){
                case "+":{ this.add(new Monomio(tk+st.nextToken())); break;}
                case "-":{ this.add(new Monomio(tk+st.nextToken())); break;}
                default: this.add(new Monomio(tk));
            }
        }
    }

    public int size(){
        return mappa.size();
    }

    @Override
    public PolinomioMap crea() {
        return new PolinomioMap();
    }

    @Override
    public void add(Monomio m) {
        if(m.getCoeff()==0) return;

        if(! mappa.containsKey(m)){
            mappa.put(m, m); return;
        }
        int somma = mappa.get(m).getCoeff()+m.getCoeff();
        if(somma==0) {
            mappa.remove(m);
            return;
        }
        Monomio m1 = new Monomio(somma, m.getGrado());
        mappa.put(m1,m1);
    }

    @Override
    public Iterator<Monomio> iterator() {
        return mappa.keySet().iterator();
    }
}
