package poo.geometria;

public interface FiguraPiana{
    double perimetro();
    double area();
}
