package poo.giochi;


public class Montecarlo{
    public static double montecarlo(long iterazioni){//metodo montecarlo
        long colpiInterni=0;
        long colpiTotali=0;
        long k =0;
		double x,y,distanzaDaOrigine;
		while(k<iterazioni){		
			x = Math.random()*2-1;//genera numeri tra [-1,1]
            y = Math.random()*2-1;
            distanzaDaOrigine = Math.sqrt(x*x + y*y);
            colpiTotali++;
			if(distanzaDaOrigine<=1)
                colpiInterni++;
            if(k%1000000==0)                
                System.out.println(4*((double)colpiInterni/colpiTotali));	  
            k++;	
        }
        return 4*((double)colpiInterni/colpiTotali);
	}
    public static void main(String[] args) {
        final double PI = montecarlo(Long.MAX_VALUE);
        System.out.println(PI);
    }
}