package poo.esempi;
import poo.util.*;

public class TestPrintArray {
    public static void main(String[] args){
        int[] mario = {10,4,2,1312,513,51,5,123,4,4};
        IO.println(mario);
    }
}
