package poo.esempi;
import poo.util.*;

public class ApprossimazioneUguaglianza{
	public static void main(String[] args){
		double x = 12.32552141241;
		double y = 12.32552141242;
		System.out.println(Mat.isEqual(x,y));
	}
}