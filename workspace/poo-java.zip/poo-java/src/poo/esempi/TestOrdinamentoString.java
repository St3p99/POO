package poo.esempi;

import java.util.Comparator;
import poo.util.Array;


class StringComparator implements Comparator<String>{
     public int compare(String s1, String s2){
        //String s1 = (String) x1; String s2 = (String) x2;
        if(s1.length() < s2.length()) return -1;
        if(s1.length() > s2.length()) return 1;
        return s1.compareTo(s2);
    }//compare
}//StringComparator

public class TestOrdinamentoString{
    public static void main(String[] args) {
        String[] v = {"edificio", "abaco", "tana","cagliostro", "zen", "VOLPE"};
        System.out.println(java.util.Arrays.toString(v));
        Array.insertionSort(v, new StringComparator());
        System.out.println(java.util.Arrays.toString(v));
    }//main
}//TestOrdinamentoString