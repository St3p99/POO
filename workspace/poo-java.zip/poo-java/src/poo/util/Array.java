package poo.util;
import poo.calendario.Data;
import poo.geometria.*;

import java.util.Comparator;

public class Array {
    //RICERCA LINEARE
    public static int ricercaLineare(int[] v, int x){
        for (int i = 0; i <v.length ; i++)
            if(v[i]==x) return i;
        return -1;
    }

    public static int ricercaLineare(double[] v, double x){
        for (int i = 0; i <v.length ; i++)
            if(Mat.isEqual(v[i],x)) return i;
        return -1;
    }

    public static int ricercaLineare(Object[] v, Object x){
        for (int i = 0; i <v.length ; i++)
            if(v[i].equals(x)) return i;
        return -1;
    }


    //RICERCA BINARIA (Hyp: giá ordinato in senso crescente)
    public static int ricercaBinaria(int[] v, int x){
        return ricercaBinaria(v, x, 0, v.length-1);
    }

    private static int ricercaBinaria(int[] v, int x, int start, int stop){
        int centro=(stop+start)/2;
        if(stop<start) return -1;
        if(x==v[centro]) return centro;
        if(x>v[centro]) return ricercaBinaria(v,x,centro+1,stop);
        else return ricercaBinaria(v,x,start,centro-1);
    }
    
    public static int ricercaBinaria(Comparable[] v, Comparable x){
        return ricercaBinaria(v, x, 0, v.length-1);
    }

    private static int ricercaBinaria(Comparable[] v, Comparable x, int start, int stop){
        int centro=(stop+start)/2;
        if(stop-start<0) return -1;
        if(x.equals(v[centro])) return centro;
        if(x.compareTo(v[centro])>0) return ricercaBinaria(v,x,centro+1,stop);
        else return ricercaBinaria(v,x,start,centro-1);
    }

    //ALG. DI ORDINAMENTO
    public static void bubbleSort(int[] v){
        int finoA=v.length;
        for (int i = 0; i < v.length-1; i++){
            int fine=finoA;
            for (int j=1; j <fine; j++)
                if(v[j-1]>v[j]){
                    swap(v,j-1,j);
                    finoA=j;
                }
        }
    }//bubbleSort

    public static void selectionSort(int[] v){
        for (int i = 0; i <v.length-1 ; i++) {
            int imin=i;
            for (int j=i+1; j<v.length; j++)
                if(v[j]<v[imin])
                    imin=j;
            swap(v, i, imin);
        }
    }//selectionSort

    public static void selectionSort(double[] v){
        for (int i = 0; i <v.length-1 ; i++) {
            int imin=i;
            for (int j=i+1; j<v.length; j++)
                if(v[j]<v[imin])
                    imin=j;
            swap(v, i, imin);
        }
    }//selectionSort

    public static void selectionSort(Comparable[] v){
        for (int i = 0; i <v.length-1 ; i++) {
            int imin=i;
            for (int j=i+1; j<v.length; j++)
                if(v[j].compareTo(v[imin])<0)
                    imin=j;
            swap(v, i, imin);
        }
    }//selectionSort applied to Comparable object


    public static void insertionSort(int[] v){
        for (int i = 1; i <v.length ; i++) {
            int val = v[i];
            for (int j = i-1; j >-1; j--)
                if(val<v[j])
                    swap(v,j+1,j);
        }
    }//insertionSort

    public static void insertionSort(Object[] v, Comparator c){
        for (int i = 0; i <v.length ; i++) {
            Object x = v[i];
            int j = 1;
            while(j>0 && c.compare(v[i-1], x)>0){
                v[j]=v[j-1]; 
                j--;
            }
            v[j] = x;
        }//for_i
    }//insertionSort

    private static void swap(int[] v, int i, int j){
        if(i==j) return;
        int z = v[j];
        v[j] = v[i];
        v[i]=z;
    }//swap
    
    private static void swap(double[] v, int i, int j){
        if(i==j) return;
        double z = v[j];
        v[j] = v[i];
        v[i]=z;
    }//swap

    private static void swap(Comparable[] v, int i, int j){
        if(i==j) return;
        Comparable z = v[j];
        v[j] = v[i];
        v[i]=z;
    }//swap
    


    //OPERAZIONI SU VETTORI
    public static double[] prodottoScalare(double[] v1, double[] v2){
        if(v1.length != v2.length)
            throw new IllegalArgumentException();
        double[] ret = new double[v1.length];
        for (int i = 0; i <v1.length ; i++)
            ret[i]=v1[i]*v2[i];
        return ret;
    }

    public static void main(String[] args){
        int[] v1 = {3,1,5,1,5,1,5,6,12,1,6,56};
        int[] v2 = {3,1,5,1,5,1,5,6,12,1,6,0};
        int[] v3 = {1,2,4,3,5,6,7,8};
        bubbleSort(v3);
        IO.printlnArray(v3);
        selectionSort(v2);
        IO.printlnArray(v2);
        insertionSort(v1);
        IO.printlnArray(v1);


        Punto p1= new Punto();
        Punto p2= new Punto(3,5);
        Disco d1= new Disco(p2,6);
        Data data1 = new Data();
        Data data2 = new Data(5,7,2018);
        Data data3 = new Data();
        Object[] o = {p1,p2,d1,data1,data2};
        System.out.println(o[ricercaLineare(o,data3)]);
        System.out.println(ricercaBinaria(v2, 1));
        System.out.println(ricercaBinaria(v3, 5));
    }
}
