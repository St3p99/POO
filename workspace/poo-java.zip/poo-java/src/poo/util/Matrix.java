package poo.util;

public class Matrix {
    public static double[][] trasposta(double[][] m){
        double[][] ret = new double[m[0].length][m.length];
        for (int i = 0; i < m.length; i++)
            for (int j = 0; j < m[0].length ; j++)
                ret[j][i] = m[i][j];
        return ret;
    }

    public static boolean eSimmetrica(double[][] m){
        if(m.length!=m[0].length)
            throw new IllegalArgumentException("Matrice non quadrata");
        for(int i=0; i<m.length; i++)
            for(int j=0; j<i; j++)
                if(m[i][j]!=m[j][i])
                    return false;
        return true;
    }

    public static double[][] somma(double[][] m1, double[][]m2){
        if(m1.length!=m2.length || m1[0].length!=m2[0].length)
            throw new IllegalArgumentException();
        double[][] ret = new double[m1.length][m2[0].length];
        for (int i = 0; i < m1.length; i++)
            for (int j = 0; j < m2[0].length ; j++)
                ret[i][j] = m1[i][j]+m2[i][j];
        return ret;
    }

    public static double[][] mul(double[][] m, double x){
        double[][] ret = new double[m.length][m[0].length];
        for (int i = 0; i < m.length; i++)
            for (int j = 0; j < m[0].length ; j++)
                ret[i][j] = m[i][j]*x;
         return ret;
    }


    public static double[][] prodotto(double[][] m1, double[][] m2){
        if(m1[0].length != m2.length)
            throw new IllegalArgumentException();
        double[][] ret = new double[m1.length][m2[0].length];
        for (int i = 0; i < m1.length; i++)
            for (int j = 0; j <m2[0].length ; j++)
                for (int k = 0; k <m2.length ; k++)
                    ret[i][j]+=m1[i][k]*m2[k][j];
        return ret;
    }//prodotto

    public static double[] prodottoMatriceVettore(double[][] m1, double[] v){
        if(m1[0].length != v.length)
            throw new IllegalArgumentException();
        double[] ret = new double[m1.length];
        for (int i = 0; i < m1.length; i++)
            for (int j = 0; j <v.length ; j++)
                    ret[i]+=m1[i][j]*v[j];
        return ret;
    }

    //RIDUZIONE DI GAUSS
    public static double[][] riduzioneDiGauss(double[][] m){
        double[][] ret = copiaMatrice(m);
        int j = preparaMatrice(ret);
        for (; j < m[0].length; j++)
            for (int i=0; i < m.length; i++) {
                if (m[i][j] == 0) continue;


            }
        return ret;
    }

    private static int preparaMatrice(double[][] m){
        //trovaPrimoElementoPivotale e lo porta nella prima riga
        boolean trovato=false;
        int pRiga=0;
        int pColonna=0;
        for (int j=0; j < m[0].length && !trovato; j++)
            for (int i=0; i < m.length && !trovato; i++)
                if(m[i][j] != 0){
                    pRiga=i; pColonna =j; trovato = true;
                }
        if(trovato)
            scambiaRighe(m, pRiga,0);
        return pColonna;

    }

    public static void scambiaRighe(double[][] m,  int ind1, int ind2){
        if(ind1==ind2) return;
        double[] copiaRiga1 = new double[m.length];
        for (int k = 0; k<m.length ; k++)
            copiaRiga1[k]=m[ind1][k];
        for (int i = 0; i <m.length ; i++){
            m[ind1][i]=m[ind2][i];
            m[ind2][i]=copiaRiga1[i];
        }


    }

    public static double[][] copiaMatrice(double[][] m){
        double[][] ret = new double[m.length][m[0].length];
        for (int i = 0; i <m.length ; i++)
            for (int j = 0; j <m[0].length ; j++)
                ret[i][j]=m[i][j];
        return ret;
    }


    public static void main(String[] args){
        /*double[][] m1 = {{102.3, 273.3,3},
                        {0,12.4,4},
                        {5,62,2},
                        {145,8,3},
                        {4,23,1}};
        double[][] m2 = {{4,21.5},
                      {23.2,100},
                      {3,70}};
        double[] v = {4,2,1};
        int[] v2= {4,2,1};
        IO.printlnMatrix(prodotto(m1,m2));
        double s = 102.3;
        IO.println(s);
        IO.printlnArray(prodottoMatriceVettore(m1,v));
        IO.println();
        IO.printlnMatrix(mul(m2,2));
        IO.println();
        IO.printlnMatrix(trasposta(m1));
        IO.println();
        IO.printlnArray(v);
        IO.printlnArray(v2);*/

        double[][] test = {{0,0,2,3},
                           {0,2,4,5},
                           {0,4,1,6},
                           {0,5,6,0}};

        IO.println(eSimmetrica(test));
        //scambiaRighe(test,1,2);
        IO.printlnMatrix(riduzioneDiGauss(test));

    }
}
